var monkey,monkeyImg;
var banana,bananaGroup,bananaImg;
var stone,stoneGroup,stoneImg;
var invisibleGround,backdrop,backImg;
var gameState = PLAY;
var PLAY = 1;
var END = 0;
var survivalTime = 0;

function preload(){
  monkeyImg = loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  backImg = loadImage("jungle.png");
  bananaImg = loadImage("banana.png");
  stoneImg = loadImage("stone.png");
}

function setup() {
  createCanvas(600, 400);
  
  backdrop = createSprite(300,200,600,400);
  backdrop.addImage(backImg);
  
  monkey = createSprite(100,300,50,50);
  monkey.addAnimation("running",monkeyImg);
  monkey.scale = 0.1;
  
  bananaGroup = new Group();
  stoneGroup = new Group();
  
  invisibleGround = createSprite(350,300,600,12);
  invisibleGround.visible = false;
}

function draw() {
  background(220);
  
  monkey.collide(invisibleGround);
  monkey.velocityY = monkey.velocityY+0.8;
  
  stroke("white");
  textSize(20);
  fill("white");
  text("Survival Time: "+survivalTime,500,50);
  
  if(gameState===PLAY){
     //jump when the space key is pressed
    if(keyDown("space") && monkey.y >= 250){
      monkey.velocityY = -16 ;
    }
    
  survivalTime = text("Survival time: "+ Math.round(frameCount/frameRate),100,100);
  
   if(monkey.isTouching(bananaGroup)){
     bananaGroup.destroyEach();
   }
    
    switch(survivalTime){
      case 10: monkey.scale = 0.12;
        break;
      case 20: monkey.scale = 0.14;
        break;
      case 30: monkey.scale = 0.16;
        break;
      case 40: monkey.scale = 0.18;
        break;
      default: break;
    }
    spawnBananas();
  
    spawnStones();
    
    if(stoneGroup.isTouching(monkey)){
      monkey.scale = 0.2;
      gameState = END;
    }
  }
  
  else if(gameState === END) {
    //monkey animation
    monkey.setAnimation("monkey_1")
    
    monkey.velocityY = 0;
    stoneGroup.setVelocityXEach(0);
    bananaGroup.setVelocityXEach(0);
    
    stoneGroup.setLifetimeEach(-1);
    bananaGroup.setLifetimeEach(-1);
    
    var survivalTime = text("Survival time: 0");
  }
  
  drawSprites();
}

function spawnStones() {
  if(frameCount % 180 === 0) {
    var stone = createSprite(600,365,10,40);
    stone.velocityX = -6
    
      stone.addImage(stoneImg);
             
    stone.scale = 0.35;
    stone.lifetime = 70;

    stoneGroup.add(stone);
  }
}

function spawnBananas() {
  if (frameCount % 120 === 0) {
    var banana = createSprite(600,150,40,10);
    banana.y = random(100,200);
    banana.addImage(bananaImg);
    banana.scale = 0.1;
    banana.velocityX = -3;
    
    banana.lifetime = 134;
    
    banana.depth = monkey.depth;
    monkey.depth = monkey.depth + 1;
    
    bananaGroup.add(banana);
  }
  
}
